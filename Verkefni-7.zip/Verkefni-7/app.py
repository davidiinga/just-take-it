from flask import Flask, render_template,session,redirect,url_for,json
from flask import request
import os
import pyrebase
from pyrebase.pyrebase import Auth
from datetime import datetime
from random import *
from requests import post
import urllib.request
app = Flask(__name__)

app.secret_key = os.urandom(8)


firebaseConfig = {
  "apiKey": "AIzaSyBTw0GwhGkmfPN_TqBmOtC97DS2LCWdU1I",
  "authDomain": "vef-7-8bd02.firebaseapp.com",
  "projectId": "vef-7-8bd02",
  "storageBucket": "vef-7-8bd02.appspot.com",
  "messagingSenderId": "379828782146",
  "appId": "1:379828782146:web:db154787f881820d7e99db",
  "measurementId": "G-MNHWWD37D3",
  "databaseURL": "https://vef-7-8bd02-default-rtdb.europe-west1.firebasedatabase.app/"
}

firebase = pyrebase.initialize_app(firebaseConfig)

db = firebase.database()

auth = firebase.auth()

@app.route("/")
def index():
  return render_template("index.html")

@app.route("/signup")
def signup():
  return render_template("signup.html")

@app.route('/login', methods=['POST'])
def login():
  session['logged'] = False
  if request.form:
    email = request.form.get("em")
    password =  request.form.get("pw")
  try:
    auth.sign_in_with_email_and_password(email, password)
    session['logged'] = True
    print('you have succesfully signed in.')
    return redirect('/logged')
  except:
    print("no good")
    return render_template("noGood.html")

@app.route('/register', methods=['POST'])
def register():
    session['logged'] = False
    if request.form:
        email = request.form.get("nem")
        password = request.form.get("npw")
        confirmpsw = request.form.get("cpw")
        if password==confirmpsw:
            try: 
                auth.create_user_with_email_and_password(email, password)
                print('Succsesfully registered')
                session['logged'] = True 
                return redirect('/logged')
            except:
                print('Sorry email-exists')
                return render_template("noGood.html")
        if password!=confirmpsw:
            print('password does not match')
            return render_template("pwmatch.html")

@app.route("/logged")
def secure():
  if "logged" in session:
    return render_template("logged.html")
  else:
    return render_template("/")

@app.route("/back")
def back():
  session.pop("logged", None)
  return redirect("/")

@app.route("/com")
def comment():
  if 'logged' in session:
    try:
      postar=db.child('postar').get().val()
      lst = list(postar.items())
      return render_template("com.html", postar=lst, tom = False)
    except:
      return redirect("com.html", tom = True)

@app.route("/article", methods=["POST"])
def aritcle():
  if request.method == "POST":

    Pistill = request.form['Pistill']
    Höfundur = request.form['Höfundur']

    db.child('postar').push({
      'Pistill':Pistill,
      'Höfundur':Höfundur
    })

    return redirect('/com')
  else:
    return render_template("error45.html")

@app.route("/update/<id>")
def update(id):
  if 'logged' in session:
    posts = db.child('postar').get()
    for p in posts.each():
      if id == p.key():
        iv = p.val()
        ik = p.key()
    return render_template('update.html', sus=iv, ik=ik)
  else:
    return render_template('error.html')

@app.route("/post-update", methods=["POST"])
def updatepost():

  if request.method == "POST":
    db.child('postar').child(request.form['id']).update({
      'Pistill':request.form['Pistill'],
      'Höfundur':request.form['Höfundur']})
    return redirect('/com')
  else:
    return render_template("error44.html")

@app.route('/delete/<id>')
def delete(id):
  if 'logged' in session:
    posts = db.child('postar').get()
    for p in posts.each():
      if id == p.key():
        db.child('postar').child(p.key()).remove()
    return redirect('/com')
  else:
    return render_template("error44.html")

@app.errorhandler(404)
def pagenotfound(error):
    return render_template('error44.html')
  
@app.errorhandler(405)
def methodnotaloud(error):
  return render_template("error45.html")

@app.route('/shows')
def showindex():

    with urllib.request.urlopen("https://api.tvmaze.com/shows") as url:
        data = json.loads(url.read().decode())

    rndShows = []

    for i in range(18):
        rndShows.append(data[randint(0,239)])
    return render_template('shows.html', gogn=rndShows)

@app.route('/show/<id>')
def show(id):

    file = "https://api.tvmaze.com/shows/%s" %id

    with urllib.request.urlopen(file) as url:
        data = json.loads(url.read().decode())
    
    return render_template( "show.html", show=data)

if __name__ == '__main__':
    app.run(debug=True, use_reloader=True)