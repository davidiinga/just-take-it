# Verkefni 7

- [Verkefni 7. Lokaverkefni](https://github.com/vefthroun/Verkefni/blob/main/Verkefni7.md)